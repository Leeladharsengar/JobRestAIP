package demo.job;
/*
import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Date;

import javax.swing.SpinnerModel;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(SpinnerModel.class)
@WebMvcTest(value = JobController.class)
@WithMockUser*/
public class JobControllerTest {/*


	
	@Test
	public void createJob() throws Exception {
		Job job = new Job(10, "SD1","Software eng",new Date("2020-08-28") ,new Date("2020-09-29"));

		// jobService.addJob to respond back with mockCourse
		Mockito.when(
				JobRepository.save(Mockito.anyString(),
						Mockito.any(Course.class))).thenReturn(mockCourse);

		// Send course as body to /students/Student1/courses
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/jobs")
				.accept(MediaType.APPLICATION_JSON).content(exampleCourseJson)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.CREATED.value(), response.getStatus());

		assertEquals("http://localhost:8089/jobs",
				response.getHeader(HttpHeaders.LOCATION));

	}	
*/}

package demo.job;


public class JobNotFoundException extends RuntimeException {

	JobNotFoundException(int id) {
		super("Could not find employee " + id);
	}
}

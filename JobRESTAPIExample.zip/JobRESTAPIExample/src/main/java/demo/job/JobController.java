package demo.job;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JobController {
	
	@Autowired
	private final JobRepository jobRepository;
	

	JobController(JobRepository repository) {
	    this.jobRepository = repository;
	  }
	
	@GetMapping(value="/jobs")
	public @ResponseBody List<Job> getJobs()
	{
		List<Job> listOfJobs = jobRepository.findAll();
		return listOfJobs;
	}
	
	@GetMapping("/jobs/{jobId}")
	public Optional<Job> retrieveDetailsForJob(@PathVariable int jobId) {

		Optional<Job> newJob = null;
		newJob = jobRepository.findById(jobId);
		if (!newJob.isPresent()) {
			new JobNotFoundException(jobId);
		}
		return newJob;
	}
	
   
    @PostMapping("/jobs")
	public @ResponseBody Job newJob(@RequestBody Job job)
	{
		Job savedJob = null;
		try {
			savedJob = jobRepository.save(job);
		} catch (Exception e) {
			// logger.warn("job has not been created ");
			// return ResponseEntity.badRequest().build();
		}
		return savedJob;

	}

    @PutMapping("/jobs/{jobId}")
	public @ResponseBody Job updateJob(@RequestBody Job job, @PathVariable int jobId)
	{
		Job updateJob = null;

		Optional<Job> jobOptional = jobRepository.findById(jobId);

		if (jobOptional.isPresent())
			updateJob = jobRepository.save(job);
		return updateJob;

	}
  
    @DeleteMapping("/jobs/{jobId}")
    void deleteEmployee(@PathVariable int jobId) {
    	jobRepository.deleteById(jobId);
    }
		
}
